# DEM STAC Catalog — Upload & Usage Guide

Generated from `dem_cog.tif` metadata (read directly with `rasterio`):

| Property | Value |
|---|---|
| CRS | EPSG:32643 (WGS 84 / UTM zone 43N) |
| Size | 1967 x 2424 px |
| Pixel size | 30 m |
| Data type | int16 |
| NoData | -32768 |
| Elevation range | 415 m – 777 m (mean 533.3 m) |
| BBox (EPSG:4326) | [74.9507, 16.6158, 75.5058, 17.2738] |
| Location | Western Ghats region, Maharashtra, India |

## 1. Files in this delivery

```
stac/
  catalog.json                          <- root STAC Catalog
  dem-collection/
    collection.json                     <- STAC Collection
    dem_cog/
      dem_cog.json                      <- STAC Item (points at your COG)
      dem_cog_thumbnail.png             <- preview image (elevation-styled)
leaflet_demo.html                       <- working Leaflet example
README.md                               <- this file
```

**Upload the whole `stac/` folder to your bucket keeping the same relative
structure**, so the final S3 layout is:

```
s3://cog-learning/dem_cog.tif                                        (already there)
s3://cog-learning/stac/catalog.json
s3://cog-learning/stac/dem-collection/collection.json
s3://cog-learning/stac/dem-collection/dem_cog/dem_cog.json
s3://cog-learning/stac/dem-collection/dem_cog/dem_cog_thumbnail.png
```

The links inside `catalog.json` / `collection.json` / `dem_cog.json` are
relative (`../`, `./`), so they only resolve correctly if this folder
structure is preserved. The `data` asset in the Item points at the
absolute COG URL you already gave me
(`https://cog-learning.s3.eu-north-1.amazonaws.com/dem_cog.tif`), so that
part works regardless of where the STAC files themselves live.

## 2. Two placeholders you should edit

I didn't have this information, so I filled in reasonable defaults —
open `dem_cog.json` / `collection.json` and adjust if needed:

- **`datetime` / temporal extent** — set to today's date (2026-08-23) as a
  placeholder "processing date". If you know the actual acquisition date
  of the source DEM (e.g. SRTM, Cartosat, ALOS AW3D30), replace it there.
- **`license`** — set to `"proprietary"`. Change to the correct SPDX id
  (e.g. `"CC-BY-4.0"`) if the DEM has an open license.

## 3. S3 CORS — required for browser access

Leaflet/JS running in a browser needs CORS headers to fetch both the
STAC JSON and the COG bytes. Add this to the bucket's CORS configuration
(S3 console → bucket → Permissions → CORS):

```json
[
  {
    "AllowedHeaders": ["*"],
    "AllowedMethods": ["GET", "HEAD"],
    "AllowedOrigins": ["*"],
    "ExposeHeaders": ["ETag", "Content-Length", "Content-Range"],
    "MaxAgeSeconds": 3000
  }
]
```

(`AllowedOrigins` can be narrowed to your actual site domain once you're
past testing.) The `Content-Range` / `Accept-Ranges` support is what lets
`geotiff.js` fetch only the tiles/overviews it needs from the COG instead
of downloading the whole file — this already works on S3 by default.

## 4. Using it in Leaflet

The DEM is only ~4.7 MB, so `leaflet_demo.html` (included) renders it
**directly in the browser** — no tile server needed:

1. It fetches `dem_cog.json` (the STAC Item) to discover the COG's URL
   (`item.assets.data.href`) and metadata.
2. It uses `geotiff.js` + `georaster` + `georaster-layer-for-leaflet` to
   read the COG (using HTTP range requests against S3, driven by the COG's
   internal tiling/overviews) and paint it as a Leaflet layer, colored by
   elevation.

Open `leaflet_demo.html` in a browser (after updating `STAC_ITEM_URL` at
the top if you host the STAC files somewhere other than the path shown)
to see it work.

**If your DEM/AOI grows much larger**, client-side rendering stops being
practical. At that point, swap in a dynamic tiler such as
[TiTiler](https://developmentseed.org/titiler/) (deployable on AWS
Lambda) pointed at the same COG URL, and replace the `georaster` block in
the demo with a plain:

```js
L.tileLayer(
  "https://<your-titiler-endpoint>/cog/tiles/{z}/{x}/{y}.png?url=" +
    encodeURIComponent(cogUrl) + "&rescale=415,777&colormap_name=terrain"
).addTo(map);
```

using `item.assets.data.href` from the STAC Item as `cogUrl`, exactly as
in the demo.

## 5. Validating the catalog

I generated these files with `pystac` from the real raster metadata, so
they're structurally valid STAC 1.1.0. If you want to run the official
schema validator yourself later (this sandbox couldn't reach
`stac-extensions.github.io` to do it here):

```bash
pip install pystac[validation]
python -c "import pystac; pystac.Catalog.from_file('stac/catalog.json').validate_all()"
```

or drop `dem_cog.json` into https://staclint.com or https://stacindex.org/validate.
